import React from 'react';
import { User, Award, Coffee, Heart } from 'lucide-react';

export default function About() {
  const stats = [
    { icon: Coffee, label: 'Projects Completed', value: '1+' },
    { icon: Award, label: 'Work Experience', value: '6 Months' },
    { icon: User, label: 'Certifications', value: '10+' },
    { icon: Heart, label: 'linkedin connections', value: '500+' },
  ];

  return (
    <section id="about" className="py-20 bg-white">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl sm:text-4xl font-bold text-gray-900 mb-4">About Me</h2>
          <p className="text-lg text-gray-600 max-w-2xl mx-auto">
A passionate web developer skilled in HTML, CSS, and JavaScript, with a strong academic foundation in Computer Science and Artificial Intelligence.          </p>
        </div>

        <div className="grid lg:grid-cols-2 gap-12 items-center mb-16">
          <div>
            <h3 className="text-2xl font-bold text-gray-900 mb-6">My Story</h3>
            <div className="space-y-4 text-gray-600 leading-relaxed">
              <p>
               I'm Shaik Mohammed Asif, a driven and curious learner with a strong foundation in computer science. My journey began with a 3-year Diploma in Computer Science and Engineering at Hindu College of Engineering and Technology (HCET), where I discovered my love for programming, logic, and building digital solutions.

              </p>
              <p>
          To take my skills further, I’m currently pursuing a B.Tech in Artificial Intelligence and Data Science at MIC College of Technology. This phase of my education is expanding my understanding of machine learning, data analytics, and intelligent systems—equipping me to solve real-world problems with smart, responsive technologies.

              </p>
              <p>
              I’m passionate about web development and specialize in HTML, CSS, and JavaScript, crafting user-friendly interfaces that blend design with functionality. My goal is to grow as a developer who not only writes clean code but also creates meaningful digital experiences.

              </p>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-6">
            {stats.map(({ icon: Icon, label, value }, index) => (
              <div 
                key={index}
                className="text-center p-6 rounded-xl bg-gradient-to-br from-blue-50 to-emerald-50 hover:shadow-lg transition-all duration-300 hover:scale-105"
              >
                <Icon size={32} className="mx-auto mb-4 text-blue-600" />
                <div className="text-2xl font-bold text-gray-900 mb-2">{value}</div>
                <div className="text-sm text-gray-600">{label}</div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}