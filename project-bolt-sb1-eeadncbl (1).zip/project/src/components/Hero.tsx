import React from 'react';
import { ArrowDown, Github, Linkedin, Mail } from 'lucide-react';

interface HeroProps {
  onNavigate: (section: string) => void;
}

export default function Hero({ onNavigate }: HeroProps) {
  return (
    <section id="home" className="min-h-screen flex items-center justify-center relative">
      <div className="absolute inset-0 bg-gradient-to-br from-blue-50 via-white to-emerald-50"></div>
      
      <div className="relative z-10 max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
        <div className="mb-8">
          <div className="w-32 h-32 mx-auto mb-6 rounded-full bg-gradient-to-br from-blue-600 to-emerald-600 flex items-center justify-center text-white text-4xl font-bold shadow-lg">
            shaik
          </div>
        </div>
        
        <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-gray-900 mb-6 leading-tight">
          Hi, I'm <span className="text-blue-600">Mohammed Asif Shaik</span>
        </h1>
        
        <p className="text-xl sm:text-2xl text-gray-600 mb-8 max-w-3xl mx-auto leading-relaxed">
          WEB Developer/I create responsive and interactive web interfaces using HTML, CSS, and                 JavaScript to deliver smooth user experiences.
        </p>
        
        <div className="flex flex-col sm:flex-row items-center justify-center gap-4 mb-12">
          <button
            onClick={() => onNavigate('projects')}
            className="bg-blue-600 text-white px-8 py-3 rounded-lg font-medium hover:bg-blue-700 transition-all duration-200 hover:scale-105 shadow-lg"
          >
            View My Work
          </button>
          <button
            onClick={() => onNavigate('contact')}
            className="border border-gray-300 text-gray-700 px-8 py-3 rounded-lg font-medium hover:border-blue-600 hover:text-blue-600 transition-all duration-200 hover:scale-105"
          >
            Get In Touch
          </button>
        </div>
        
        <div className="flex items-center justify-center space-x-6 mb-12">
          <a 
            href="https://github.com/AsifShaikS01" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-gray-600 hover:text-blue-600 transition-colors"
          >
            <Github size={24} />
          </a>
          <a 
            href="https://www.linkedin.com/in/mohammed-asif-shaik-680924291/" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-gray-600 hover:text-blue-600 transition-colors"
          >
            <Linkedin size={24} />
          </a>
          <a 
            href="shaikasifskmohammedasi@gmail.com"
            className="text-gray-600 hover:text-blue-600 transition-colors"
          >
            <Mail size={24} />
          </a>
        </div>
      </div>
      
      <button 
        onClick={() => onNavigate('about')}
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 text-gray-600 hover:text-blue-600 transition-colors animate-bounce"
      >
        <ArrowDown size={30} />
      </button>
    </section>
  );
}